# GMP 6.3.0 corresponding source and build instructions

The unmodified upstream tarball gmp-6.3.0.tar.xz is included verbatim.
SHA256: a3c2b80201b89e68616f4ad30bc66aee4927c3ce50e33929ca819d5c43538898
Source: https://ftp.gnu.org/gnu/gmp/gmp-6.3.0.tar.xz
GMP is distributed under LGPL-3.0-or-later. Full LGPLv3 and GPLv3 texts
and component notices accompany this archive and each runtime archive.

Prerequisites (maintainers or recipients modifying GMP): Python >=3.9,
a C compiler, bash, GNU make, m4, and the platform SDK. On Windows use
MSYS2 MINGW64 with mingw-w64-x86_64-gcc, make, m4 and diffutils. No
system installation is performed; make install writes to the private prefix.

From this extracted directory run:

    python -c 'from build_runtime import build_gmp, host_target; build_gmp("gmp-6.3.0.tar.xz", "gmp-build", host_target())'

The unchanged source is configured with --enable-shared --disable-static
--disable-cxx --disable-assembly and CFLAGS=-O2; macOS additionally uses
-mmacosx-version-min=15.0, Windows --host=x86_64-w64-mingw32 CC=gcc LDFLAGS=-static-libgcc.
The script contains the exact commands, runs make check, and saves build
provenance in gmp-build/install/kpopper-gmp-provenance.json. No GMP source
patches are used. The included workflow records the producer platform setup.

Use the resulting ABI-compatible library to replace the library in your
extracted runtime cache: .dylibs/libgmp.10.dylib on macOS,
.libs/libgmp.so.10 on Linux, libgmp-10.dll on Windows. On macOS run
install_name_tool -id @loader_path/.dylibs/libgmp.10.dylib FILE
and codesign --force --sign - FILE. These load-name/signature adjustments
are the only post-build modifications. No distributor signing key or
application relink is needed. Modification/reverse engineering to debug
GMP modifications is permitted. The runtime reports replacement identity.

Optional replacement test: build_gmp(..., replacement_probe=True) appends
replacement-constructor.txt to version.c before building. This separately
identified test change prints KPOPPER_GMP_REPLACEMENT_PROBE to stderr.
It is never applied to production GMP archives.
